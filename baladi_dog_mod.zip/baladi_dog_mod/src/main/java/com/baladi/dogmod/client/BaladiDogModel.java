package com.baladi.dogmod.client;

import com.baladi.dogmod.BaladiDog;
import com.baladi.dogmod.BaladiDogMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Wolf-layout model (64x32 texture) with a gallop animation and a collar ring. */
public class BaladiDogModel extends EntityModel<BaladiDog> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(BaladiDogMod.MODID, "baladi_dog"), "main");

    private final ModelPart head, realHead, body, upperBody, collar;
    private final ModelPart rightHindLeg, leftHindLeg, rightFrontLeg, leftFrontLeg;
    private final ModelPart tail;

    public BaladiDogModel(ModelPart root) {
        this.head = root.getChild("head");
        this.realHead = head.getChild("real_head");
        this.body = root.getChild("body");
        this.upperBody = root.getChild("upper_body");
        this.collar = root.getChild("collar");
        this.rightHindLeg = root.getChild("right_hind_leg");
        this.leftHindLeg = root.getChild("left_hind_leg");
        this.rightFrontLeg = root.getChild("right_front_leg");
        this.leftFrontLeg = root.getChild("left_front_leg");
        this.tail = root.getChild("tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create(),
                PartPose.offset(-1.0F, 13.5F, -7.0F));
        head.addOrReplaceChild("real_head", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-2.0F, -3.0F, -2.0F, 6.0F, 6.0F, 4.0F)
                .texOffs(16, 14).addBox(-2.0F, -5.0F, 0.0F, 2.0F, 2.0F, 1.0F)
                .texOffs(16, 14).addBox(2.0F, -5.0F, 0.0F, 2.0F, 2.0F, 1.0F)
                .texOffs(0, 10).addBox(-0.5F, 0.0F, -5.0F, 3.0F, 3.0F, 4.0F), PartPose.ZERO);

        root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(18, 14).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 9.0F, 6.0F),
                PartPose.offsetAndRotation(0.0F, 14.0F, 2.0F, Mth.HALF_PI, 0.0F, 0.0F));
        root.addOrReplaceChild("upper_body", CubeListBuilder.create()
                .texOffs(21, 0).addBox(-3.0F, -3.0F, -3.0F, 8.0F, 6.0F, 7.0F),
                PartPose.offsetAndRotation(-1.0F, 14.0F, -3.0F, Mth.HALF_PI, 0.0F, 0.0F));

        // collar ring around the neck (only visible in the collar layer texture)
        root.addOrReplaceChild("collar", CubeListBuilder.create()
                .texOffs(42, 14).addBox(-4.5F, -4.0F, -1.0F, 9.0F, 8.0F, 2.0F),
                PartPose.offset(0.0F, 13.5F, -5.0F));

        CubeListBuilder leg = CubeListBuilder.create().texOffs(0, 18).addBox(0.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F);
        CubeListBuilder legM = CubeListBuilder.create().mirror().texOffs(0, 18).addBox(0.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F);
        root.addOrReplaceChild("right_hind_leg", leg, PartPose.offset(-2.5F, 16.0F, 7.0F));
        root.addOrReplaceChild("left_hind_leg", legM, PartPose.offset(0.5F, 16.0F, 7.0F));
        root.addOrReplaceChild("right_front_leg", leg, PartPose.offset(-2.5F, 16.0F, -4.0F));
        root.addOrReplaceChild("left_front_leg", legM, PartPose.offset(0.5F, 16.0F, -4.0F));

        PartDefinition tail = root.addOrReplaceChild("tail", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-1.0F, 12.0F, 8.0F, -0.7F, 0.0F, 0.0F));
        tail.addOrReplaceChild("real_tail", CubeListBuilder.create()
                .texOffs(9, 18).addBox(0.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(BaladiDog e, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        head.xRot = headPitch * Mth.DEG_TO_RAD;
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;

        float wag = e.isTame() ? Mth.cos(ageInTicks * 0.4F) * 0.25F : 0.0F;
        tail.yRot = wag;

        if (e.isInSittingPose()) {
            upperBody.setPos(-1.0F, 16.0F, -3.0F);
            upperBody.xRot = 1.2566371F;
            body.setPos(0.0F, 18.0F, 0.0F);
            body.xRot = Mth.PI / 4.0F;
            collar.setPos(0.0F, 15.5F, -5.0F);
            collar.xRot = -0.31F;
            head.setPos(-1.0F, 15.5F, -7.0F);
            tail.setPos(-1.0F, 21.0F, 6.0F);
            tail.xRot = 0.3F;
            rightHindLeg.setPos(-2.5F, 22.7F, 2.0F);
            leftHindLeg.setPos(0.5F, 22.7F, 2.0F);
            rightHindLeg.xRot = leftHindLeg.xRot = Mth.PI * 1.5F;
            rightFrontLeg.setPos(-2.49F, 17.0F, -4.0F);
            leftFrontLeg.setPos(0.51F, 17.0F, -4.0F);
            rightFrontLeg.xRot = leftFrontLeg.xRot = 5.811947F;
            return;
        }

        body.setPos(0.0F, 14.0F, 2.0F);
        upperBody.setPos(-1.0F, 14.0F, -3.0F);
        collar.setPos(0.0F, 13.5F, -5.0F);
        collar.xRot = 0.0F;
        head.setPos(-1.0F, 13.5F, -7.0F);
        tail.setPos(-1.0F, 12.0F, 8.0F);
        rightHindLeg.setPos(-2.5F, 16.0F, 7.0F);
        leftHindLeg.setPos(0.5F, 16.0F, 7.0F);
        rightFrontLeg.setPos(-2.5F, 16.0F, -4.0F);
        leftFrontLeg.setPos(0.5F, 16.0F, -4.0F);
        body.xRot = upperBody.xRot = Mth.HALF_PI;
        tail.xRot = -0.7F;

        boolean gallop = e.isAggressive() && limbSwingAmount > 0.05F;
        if (gallop) {
            // Running (gallop): front legs together, hind legs together, body bounces
            float t = limbSwing * 0.55F;
            float amp = 1.9F * Math.min(limbSwingAmount, 1.0F);
            float front = Mth.cos(t) * amp;
            float hind = Mth.cos(t + 0.9F) * amp;
            rightFrontLeg.xRot = leftFrontLeg.xRot = front;
            rightHindLeg.xRot = leftHindLeg.xRot = hind;
            float bob = Mth.cos(t * 2.0F) * 0.9F * Math.min(limbSwingAmount, 1.0F);
            float arch = Mth.sin(t) * 0.08F * Math.min(limbSwingAmount, 1.0F);
            body.y += bob; upperBody.y += bob; head.y += bob; collar.y += bob; tail.y += bob;
            body.xRot += arch; upperBody.xRot += arch;
            tail.xRot = -0.3F + Mth.sin(t) * 0.2F;
        } else {
            float swing = 1.4F * limbSwingAmount;
            rightHindLeg.xRot = Mth.cos(limbSwing * 0.6662F) * swing;
            leftHindLeg.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * swing;
            rightFrontLeg.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * swing;
            leftFrontLeg.xRot = Mth.cos(limbSwing * 0.6662F) * swing;
        }
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, int color) {
        head.render(ps, vc, light, overlay, color);
        body.render(ps, vc, light, overlay, color);
        upperBody.render(ps, vc, light, overlay, color);
        collar.render(ps, vc, light, overlay, color);
        rightHindLeg.render(ps, vc, light, overlay, color);
        leftHindLeg.render(ps, vc, light, overlay, color);
        rightFrontLeg.render(ps, vc, light, overlay, color);
        leftFrontLeg.render(ps, vc, light, overlay, color);
        tail.render(ps, vc, light, overlay, color);
    }
}
