package com.baladi.dogmod.client;

import com.baladi.dogmod.BaladiDog;
import com.baladi.dogmod.BaladiDogMod;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class BaladiDogRenderer extends MobRenderer<BaladiDog, BaladiDogModel> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(BaladiDogMod.MODID, "textures/entity/baladi_dog.png");

    public static final float SCALE = 3.0F; // 3x wolf

    public BaladiDogRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new BaladiDogModel(ctx.bakeLayer(BaladiDogModel.LAYER_LOCATION)), 0.5F * SCALE);
        this.addLayer(new BaladiDogCollarLayer(this));
    }

    @Override
    protected void scale(BaladiDog entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public ResourceLocation getTextureLocation(BaladiDog entity) {
        return TEXTURE;
    }
}
